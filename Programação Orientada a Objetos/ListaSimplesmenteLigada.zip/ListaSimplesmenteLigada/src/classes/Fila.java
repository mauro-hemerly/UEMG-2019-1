 
package classes;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Fila<E> {
    private ListaLigada<E> ll;
    
    public Fila() {
        ll = null;
    } 
    
    public void insere(E elem) {
        ll.insereUltimo(elem);
    }
    
    
    public E remove() {
        return ll.removeCabeca();
    }
    
    public void escreveFila() {
        ll.escreveListaLigada();
    }
}
