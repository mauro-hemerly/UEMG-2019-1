 
package classes;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class ListaLigada<E> {
    private No<E> cab;
    private No<E> ultimo;
    private int nElementos;
    
    
    public ListaLigada() {
        cab = null;  // lista vazia
        ultimo = null;
        nElementos = 0;
    }
    
    // Insere novo elemento no início da lista
    public void insere(E novoElemento) {
       
        No<E> nv = new No<>(novoElemento);   // instancia novo
        nv.setProx(cab);  // ajusta a ligacao do novo nó com a lista
        cab = nv;   // ajustar a nova cabeça da lista
        
        
        nElementos++; // atualiza o número de elementos na lista
    }
    
    
    public boolean vazia() {
        return cab == null;
    }
    
    //Remove a cabeça da lista
    
    public E removeCabeca() {
        E info = null;
        No<E> aux;
        
        if (!vazia()) {  // lista não vazia ?
            info = cab.getInfo();
            aux = cab;
            cab = cab.getProx();
            aux.setInfo(null);
            aux.setProx(null);
            
             
            
        }
        
        return info;
    }
    
    
    public void escreveListaLigada() {
        No<E> t = cab; 
        while(t != null) {
            System.out.println(t.getInfo().toString());
            t = t.getProx();
        }
    }
    
    public void insereUltimo(E nv){
        No<E> novoElemento = new No<>(nv);
        nElementos++;
        
        if (vazia()) { //lista vazia?
            //sim
            cab = novoElemento;
            
        }
        else {  //não
            ultimo.setProx(novoElemento);
        }
        ultimo = novoElemento;
    }

}    
  