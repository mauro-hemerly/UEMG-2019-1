 
package classes;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Pilha<E> {
    private ListaLigada<E> ll;

    public Pilha() {
        ll = new ListaLigada<>();
    }
    
    
    public void push(E elem) {
        ll.insere(elem);
    }
    
    public E pop() {
        if (!vazia()) {
            return ll.removeCabeca();
        }
        return null;
    }
    
    public boolean vazia() {
        return ll.vazia();
    }

    public void insere(Produto produto) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    public void escrevePilha() {
        ll.escreveListaLigada();
    }
    
}
