 
package classes;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class No<E> {
    private E info;
    private No<E> prox;
    
    public No(E info) {
        this.info = info;
        this.prox = null;
    }

    public E getInfo() {
        return info;
    }

    public void setInfo(E info) {
        this.info = info;
    }

    public No<E> getProx() {
        return prox;
    }

    public void setProx(No<E> prox) {
        this.prox = prox;
    }
    
    
    
}
