 
package principal;

import classes.Pilha;
import classes.Produto;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class UsaPilha {
    public static void main(String[] args) {
        Pilha<Produto> pi1 = new Pilha<>();
        
        pi1.push(new Produto("TV LCD SONY", "123"));
        pi1.push(new Produto("TV LCD SAMSUNG", "123567"));
        pi1.push(new Produto("TV LCD PANASONIC", "123897"));
        
        
        pi1.escrevePilha();
        
        pi1.pop();
        
        pi1.escrevePilha();
    }
}
