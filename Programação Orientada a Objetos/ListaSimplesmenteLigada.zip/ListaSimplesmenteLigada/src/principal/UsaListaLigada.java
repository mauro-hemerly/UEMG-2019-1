 
package principal;

import classes.ListaLigada;
import classes.Produto;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class UsaListaLigada {
    public static void main(String[] args) {
        ListaLigada<Produto> ll1 = new ListaLigada<>();
        
        ll1.insere(new Produto("TV LCD SONY", "123"));
        ll1.insere(new Produto("TV LCD SAMSUNG", "123567"));
        ll1.insere(new Produto("TV LCD PANASONIC", "123897"));
         
        
        ll1.escreveListaLigada();
        
        ll1.removeCabeca();
         ll1.escreveListaLigada();
        
    }
}
