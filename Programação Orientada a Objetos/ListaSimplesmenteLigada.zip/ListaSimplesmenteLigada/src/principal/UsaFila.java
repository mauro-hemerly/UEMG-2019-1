 
package principal;

import classes.Fila;
import classes.Produto;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class UsaFila {
    public static void main(String[] args) {
        Fila<Produto> pi1 = new Fila<>();
        
         pi1.insere(new Produto("TV LCD SONY", "123"));
        pi1.insere(new Produto("TV LCD SAMSUNG", "123567"));
        pi1.insere(new Produto("TV LCD PANASONIC", "123897"));
        
        
        pi1.escreveFila();
    }
}
