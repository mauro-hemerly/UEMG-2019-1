 
package br.uemg.classes;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Professor extends Pessoa {
    private String matricula;

    public Professor(String nome, String cpf, String eMail) {
        super(nome, cpf, eMail);
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
    
     @Override
    public String getNome() {
        return super.getNome();
    }
    
    @Override
     public String getCpf() {
        return super.getCpf();
    }
     
    @Override
     public void setNome( String nome ) {
         super.setNome(nome);
     }

    @Override
    public void setCpf(String cpf) {
        super.setCpf(cpf);
    }

    @Override
    public String geteMail() {
        return super.geteMail();
    }

    @Override
    public void seteMail(String eMail) {
        super.seteMail(eMail);
    }

    @Override
    public String toString() {
        return "Professor{" + "matricula=" + matricula + super.toString() + '}';
    }
    
    
}
