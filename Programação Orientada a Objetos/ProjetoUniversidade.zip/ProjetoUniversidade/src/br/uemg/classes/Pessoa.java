package br.uemg.classes;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Pessoa {

    private String nome;
    private String cpf;
    private String eMail;

    public Pessoa(String nome, String cpf, String eMail) {
        this.nome = nome;
        this.cpf = cpf;
        this.eMail = eMail;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    @Override
    public String toString() {
        return "Pessoa{" + "nome=" + nome + ", cpf=" + cpf + ", eMail=" + eMail + '}';
    }

    
}
