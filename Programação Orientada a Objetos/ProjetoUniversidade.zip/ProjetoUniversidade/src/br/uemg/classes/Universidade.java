 
package br.uemg.classes;

import java.util.ArrayList;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Universidade {
    private String nomeIES;
    private ArrayList<Curso> cursos;

    public Universidade(String nomeIES) {
        this.nomeIES = nomeIES;
        cursos = new ArrayList<>();
    }

    public String getNomeIES() {
        return nomeIES;
    }

    public void setNomeIES(String nomeIES) {
        this.nomeIES = nomeIES;
    }

    public ArrayList<Curso> getCursos() {
        return cursos;
    }
 
    
    public void cadastraCurso( Curso curso ) {
        this.cursos.add(curso);
    }

    @Override
    public String toString() {
        return "Universidade{" + "nomeIES=" + nomeIES + ", cursos=" + cursos + '}';
    }
    
    
    
    
}
