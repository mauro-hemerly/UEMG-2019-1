 
package br.uemg.classes;

import java.util.ArrayList;



/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Curso {
    private String nome;
    private String nomeCoordenador;
    ArrayList<Disciplina> disciplinas;

    public Curso(String nome, String nomeCoordenador) {
        this.nome = nome;
        this.nomeCoordenador = nomeCoordenador;
        this.disciplinas = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNomeCoordenador() {
        return nomeCoordenador;
    }

    public void setNomeCoordenador(String nomeCoordenador) {
        this.nomeCoordenador = nomeCoordenador;
    }

    public ArrayList<Disciplina> getDisciplinas() {
        return disciplinas;
    }

    public void cadastraDisciplina( Disciplina  disciplina) {
        this.disciplinas.add(disciplina);
    }
    
    public void cadastraDisciplina( String nome, String codigo ) {
        Disciplina d = new Disciplina(nome,codigo);
        this.disciplinas.add(d);
    }
    

    @Override
    public String toString() {
        return "Curso{" + "nome=" + nome + ", nomeCoordenador=" + nomeCoordenador + ", disciplinas=" + disciplinas + '}';
    }
    
    
    
    
}
