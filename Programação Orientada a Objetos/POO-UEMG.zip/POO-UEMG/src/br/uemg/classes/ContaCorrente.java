

package br.uemg.classes;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class ContaCorrente {
   private String numero;
   private double saldo;
   private double limite;
   
    
    
//    // Construtor default
//    public ContaCorrente() {
//        numero = "123456-9";
//        saldo = 100.00;
//    }
//    
//    
//    // Construtor com Parâmetros
    public ContaCorrente( String num, double saldoInicial, double lim ) {
        numero = num;
        saldo = saldoInicial;
        limite = lim;
    }
    
    
    // Construtor de cópia (clonagem)
    public ContaCorrente( ContaCorrente cc ) {
        this.numero = cc.numero;
        this.saldo = cc.saldo;
        this.limite = cc.limite;
       
    }
    
    
    // Compara dois objetos, retornando true para iguais e false para diferentes.
    public boolean igual( ContaCorrente cc ) {
        if ( this == cc ) {
            return true;
        }
        
        if ( this.numero.equals( cc.numero ) &&
            ( Math.abs( this.saldo - cc.saldo ) < 0.00000000001   ) &&
            ( Math.abs( this.limite - cc.limite ) < 0.00000000001 )) {
            return true;
        }
        return false;
                
    }
    
    public void depositar( double valor ) {
        saldo = saldo + valor;     // saldo += valor;
    }
    
    /**
    Saca um valor especificado pelo parâmetro valor.
    * @param valor valor a ser sacado da conta corrente.
    @return um valor booleano especificando se o saque foi realizado com ou sem sucesso.*/
    public boolean sacar( double valor ) {
        if ( valor <= saldo+limite ) {
            saldo = saldo - valor;    // saldo -= valor;
            return true;  // saque realizado com sucesso
        }
        
        return false;  // saque não autorizado
    }
    
    /**
    * Obtém o número da conta corrente.
    @return uma String especificando o número da conta. */
    public String obterNumero() {
        return numero;
    }
    
     /**
    Obtém o saldo atual (sem o limite) da conta corrente.
    @return um valor especificando o saldo atual. */
    public double obterSaldo() {
        return saldo;
    }
    
    /**
    Obtém o saldo total (saldo atual + limite) da conta corrente.
    @return um valor especificando o saldo total. */
    
    public double obterSaldoTotal() {
        return limite+saldo;
    }
    
    
    
}
   
