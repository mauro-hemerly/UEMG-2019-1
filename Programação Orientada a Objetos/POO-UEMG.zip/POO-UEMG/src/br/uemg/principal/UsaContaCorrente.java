package br.uemg.principal;

import br.uemg.classes.*;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class UsaContaCorrente {

    public static void main(String[] args) {
        
        
        int i = 99;

        // Usa construtor com parâmetros
        ContaCorrente cc1 = new br.uemg.classes.ContaCorrente("5678", 999.99, 1000.00);

        ContaCorrente cc2 = new br.uemg.classes.ContaCorrente("5678", 999.99, 1001.00);

        //System.out.println(cc1 == cc2);

         

        System.out.println(cc1.igual(cc2));

    }
    
    
}
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

}
