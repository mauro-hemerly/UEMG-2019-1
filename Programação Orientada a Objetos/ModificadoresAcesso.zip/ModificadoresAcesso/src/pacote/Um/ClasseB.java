/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pacote.Um;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class ClasseB extends ClasseA {
    public void metodoB() {
        ClasseA a1 = new ClasseA();
        a1.x = a1.x + 100;
        a1.y = a1.y + 200;
        z = z + 300;
     //   a1.w = a1.w + 400;
    }
}
