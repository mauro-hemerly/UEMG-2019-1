/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pacote.Um;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class ClasseA {
   public int x = 11;
        int y = 22;
   protected  int z = 33;
   private int w = 44;
}
