 
package pacote.Um;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class ClasseA {
   public       int x = 11;
   protected    int y = 22;
                int z = 33;
   private      int w = 44;
}
