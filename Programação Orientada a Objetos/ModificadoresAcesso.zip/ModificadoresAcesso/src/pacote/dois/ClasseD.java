
package pacote.dois;

import pacote.Um.*;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class ClasseD extends ClasseA {
     public void metodoD() {
        ClasseA a1 = new ClasseA();
        a1.x = a1.x + 100;
     //   a1.y = a1.y + 200;
        z = z + 300;
     //   a1.w = a1.w + 400;
    }
}
