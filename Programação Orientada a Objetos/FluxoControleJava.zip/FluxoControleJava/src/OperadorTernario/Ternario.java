 
package OperadorTernario;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Ternario {

    public static void main(String[] args) {

    }

    static int ternary(int i) {
        return i < 10 ? i * 100 : i * 10;
    }

    static int alternative(int i) {
        if (i < 10) {
            return i * 100;
        } else {
            return i * 10;
        }
    }
}
