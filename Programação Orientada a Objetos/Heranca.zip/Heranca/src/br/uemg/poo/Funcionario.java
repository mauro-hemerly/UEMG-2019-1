
package br.uemg.poo;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */


public class Funcionario {
    private String nome;
    private String cpf;
    private double salario;
    private final double BONIFICACAO_SALARIAL = 0.10;   // Bonificação de 10%
    
    public Funcionario( String nome, String cpf, double salario ) {
        this.nome = nome;
        this.cpf = cpf;
        this.salario = salario;
    };
    
    // construtor de cópia
    public Funcionario( Funcionario f ) {
        this.nome = f.nome;
        this.cpf = f.cpf;
        this.salario = f.salario;
    }

    // Clona objeto encapsulado
    public Funcionario copia() {
        return new Funcionario( this );
    }

    public double getBonificacao() {
        return this.salario * BONIFICACAO_SALARIAL;    
    };

    public String getCpf() {
        return cpf;
    };

    public void setCpf( String cpf ) {
        this.cpf = cpf;
    };

    public String getNome() {
        return nome;
    };

    public void setNome( String nome ) {
        this.nome = nome;
    };

    public double getSalario() {
        return salario;
    };

    public void setSalario(double salario) {
        this.salario = salario;
    };

    @Override
    public boolean equals(Object obj) {
        if ( obj == null ) {
            return false;
        }

        if ( getClass() != obj.getClass() ) {
            return false;
        }

        Funcionario func = (Funcionario) obj;

        if ( !this.nome.equals(func.nome) ) {
            return false;
        }

        if ( !this.cpf.equals(func.cpf)) {
            return false;
        }

        if ( this.salario != func.salario ) {
            return false;
        }


        return true; // objeto atual (this) e objeto obj são iguais
    }

 
    @Override
    public String toString() {  // método sobrescrito da classe Object
        return "Nome: " + nome + "     CPF: " + cpf + "     Salário = R$ " + salario;
    };


     public String minhaClasse() {
      return "Classe Funcionario"  ;
    };

};
