 
package br.uemg.poo;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */


/*
 *   +---------+                 +-------------+
 *   | Gerente |----------------|>| Funcionario |
 *   +---------+                  +-------------+
 * 
 */

public class Gerente extends Funcionario {
    private final double BONIFICACAO_SALARIAL = 0.25;  // Bonificação de 25%
    
    public Gerente( String nome, String cpf, double salario ) {
        super( nome,cpf, salario );
    };
    
    @Override      // Garantir que está sobrescrevendo um método e não criando um novo.
    public double getBonificacao() {
        return getSalario() * BONIFICACAO_SALARIAL;   
    };

    @Override
    public String toString() {   // método sobrescrito da classe Funcionario
        return "Gerente -> " + super.toString() + "   Salario = R$ " + getSalario();  //  e sem a palavra super, o que ocorreria ?
    };

    @Override
     public String minhaClasse() {
      return "Classe Gerente"  ;
    };

    
};
