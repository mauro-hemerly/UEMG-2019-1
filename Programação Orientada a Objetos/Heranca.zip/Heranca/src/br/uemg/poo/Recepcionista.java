 
package br.uemg.poo;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Recepcionista extends Funcionario {

    public Recepcionista( String nome, String cpf, double salario ) {
        super( nome, cpf, salario );
    };  
   
     
    @Override    // Garantir que está sobrescrevendo um método e não criando um novo.
    public String toString() {   // método sobrescrito da classe Funcionario
        return "Recepcionista -> " + super.toString()  + "   Bonificação = R$ " + getBonificacao();  //  e sem a palavra super, o que ocorreria ?
    };

     @Override
     public String minhaClasse() {
      return "Classe Recepcionaista"  ;
    };

};
