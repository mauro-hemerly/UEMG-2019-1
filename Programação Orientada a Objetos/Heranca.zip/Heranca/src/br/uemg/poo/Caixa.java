 
package br.uemg.poo;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Caixa extends Funcionario {
    //private int idade;
    private final double BONIFICACAO_SALARIAL = 0.15;    // Bonificação de 15%

    // Clona objeto encapsulado
    @Override    // Garantir que está sobrescrevendo um método e não criando um novo.
      public Caixa copia() {
        return new Caixa(this); // invoca construtor de cópia
    }


    // Construtor de Cópia
    public Caixa ( Caixa cx ) {
        super(cx);
       // this.idade = cx.idade;
    }



    public Caixa ( String nome, String cpf, double salario, int idade ) {
        super( nome,cpf, salario );
        //this.idade = idade;
    };
    
    @Override
    public double getBonificacao() {
        return getSalario() * BONIFICACAO_SALARIAL;   
    };
    
    @Override
    public String toString() {   // método sobrescrito da classe Funcionario
        return "Caixa -> " + super.toString()  + "    Bonificação = R$ " + getBonificacao() ;   //  e sem a palavra super, o que ocorreria ?
    };


    public String minhaClasse() {
      return " Classe Caixa"  ;
    };




//    @Override
//    public boolean equals( Object o ) {
//        if (o == null) {
//            return false;
//        }
//
//        if (this.getClass() != o.getClass()) {
//            return false;
//        }
//        Caixa cx = (Caixa)o;
//        return ( super.equals(o)); 
//    }



};
