
package br.uemg.poo;
import java.util.ArrayList;


/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 * 
 */

/*
 *   +---------+ 1             * +-------------+
 *   | Banco   |---------------->| Funcionario |
 *   +---------+                 +-------------+
 * 
 */

public class Banco {
    private String nome;  // razão social do banco
    private ArrayList<Funcionario> funcionarios;  // lista de cadastro dos funcionários
    private double totalDeBonificacoes = 0.0;
    
    public Banco( String nome ) {
        this.nome = nome;
        funcionarios = new ArrayList<Funcionario>();
    };
    
    public void contrataFuncionario( Funcionario func ) {

        System.out.println("***" + func.minhaClasse());

        Funcionario f = func.copia(); // cópia defensiva
        funcionarios.add( f );
        this.totalDeBonificacoes += func.getBonificacao();
    };


    public ArrayList<Funcionario> getFuncionarios() {
        ArrayList<Funcionario> copia = new ArrayList<Funcionario>();
        
        for(Funcionario f : funcionarios) {
            copia.add(f.copia());
        }
        return copia;  
    }

    public double getTotalDeBonificacoes() {
        return this.totalDeBonificacoes;
    };
    
    
    @Override
    public String toString() {
      StringBuilder f = new StringBuilder();
      f.append("Banco: ");
      f.append(nome);
      f.append("\n");
      
      for(Funcionario func : funcionarios) {  // foreach
          f.append(func.toString());
          f.append("\n");
      };
      
      return f.toString();  
    };
    
    
    public String minhaClasse() {  // classe Banco não estende nenhuma classe que possua este método !
      return "Classe Banco"  ;
    };
    
};