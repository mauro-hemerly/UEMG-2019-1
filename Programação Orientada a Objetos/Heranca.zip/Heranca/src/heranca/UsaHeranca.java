
package heranca;

import br.uemg.poo.Caixa;
import br.uemg.poo.Funcionario;
import br.uemg.poo.Gerente;
import br.uemg.poo.Recepcionista;
import br.uemg.poo.Banco;
import java.util.ArrayList;


/**
 *
 * @author Mauro Hemerly (Hämmerli) gazzani
 */
public class UsaHeranca {
    
    public static void main( String[] args ) {
        Banco bc1 = new Banco( "Bradesco" );
        
        Gerente gerente = new Gerente( "John Doe","123456789-00", 1600.00 );
        bc1.contrataFuncionario( gerente );
        
        System.out.println(bc1);
        System.out.println("\n\n\n");
        gerente.setSalario(100000.00);
        System.out.println(bc1);
        
        
        
        ArrayList<Funcionario> f = bc1.getFuncionarios();

        f.get(0).setSalario(200000);

        System.out.println(bc1);
        
           
        Caixa caixa1 = new Caixa( "Jane Doe","123456789-11", 1200.00, 30 );
        bc1.contrataFuncionario( caixa1 );

         Caixa caixa2 = new Caixa( "Jane Doe","123456789-11", 1200.00, 30 );
        bc1.contrataFuncionario( caixa2 );
        
        Recepcionista recepcionista = new Recepcionista( "Mary Doe","123456789-22", 980.00 );
        bc1.contrataFuncionario( recepcionista );

        Caixa caixa3 = caixa2.copia();

        

        System.out.println("**** Testanto equals: " + caixa2);


        ArrayList<Funcionario> funcEquals = new ArrayList<Funcionario>();

        funcEquals.add( caixa1 );

         System.out.println( "Testando equals: " + funcEquals.contains( caixa2 ) );



        ArrayList<Funcionario> funcs = bc1.getFuncionarios();

        for( Funcionario func : funcs ) {  // uso do foreach
            System.out.println( func.getSalario() );
        }

        System.out.println( "\n\n" );  // salta 3 linhas

        System.out.println(caixa1.equals(caixa2));  // compara dois objetos do tipo Caixa

        //System.out.println(bc1);
  

       

        
        

       

        Gerente gerente2 = new Gerente( "John Doe","123456789-00", 1600.00 );
        //System.out.println( "Testando Equals: " + funcEquals.contains(gerente2) );

        


        

        
        // Gerente ger = (Gerente) new Funcionario("João Paulo","242424");   (downcasting)
        
        
    };
};
