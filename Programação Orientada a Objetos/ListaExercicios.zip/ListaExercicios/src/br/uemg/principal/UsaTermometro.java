package br.uemg.principal;

import br.uemg.classes.Termometro;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class UsaTermometro {

    public static void main(String[] args) {
        Termometro term1 = new Termometro();
        Termometro term2 = new Termometro();

        System.out.println("Antes:");
        System.out.println("Term1: " + term1.getTemperatura());
        System.out.println("Term2: " + term2.getTemperatura());

        term1.aquecer();
        term2.esfriar();

        System.out.println("Depois:");
        System.out.println("Term1: " + term1.getTemperatura());
        System.out.println("Term2: " + term2.getTemperatura());

        // Uso do Construtor de Cópia
        Termometro term3 = new Termometro(term2);
        System.out.println("Term3: " + term3.getTemperatura());

        System.out.println(term3.iguais(term2) ? "Iguais..." : "Diferentes...");
    }
}
