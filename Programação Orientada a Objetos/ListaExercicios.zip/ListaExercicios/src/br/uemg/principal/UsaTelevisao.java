 
package br.uemg.principal;

import br.uemg.classes.Televisao;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class UsaTelevisao {
    public static void main(String[] args) {
        Televisao tv1 = new Televisao();
        
        Televisao tv2 = new Televisao();
        
        
        System.out.println( tv1 );
        System.out.println( tv2);
        
        
        tv1.trocaCanal( 15 );
        tv1.ligaDesliga();
        System.out.println( tv1 );
        
        Televisao tv3 = tv1;
        System.out.println( tv1.iguais( tv3 ) );
        
        tv1.avancaCanal();
        System.out.println( tv1 );
    }
}
