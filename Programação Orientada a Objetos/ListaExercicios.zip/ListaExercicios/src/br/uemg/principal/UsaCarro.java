 
package br.uemg.principal;

import br.uemg.classes.Carro;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class UsaCarro {
    public static void main(String[] args) {
        
        Carro car1 = Carro.criaCarro( "Preto", "Toyota","Corolla","Flex: gasolina/alcool");
        Carro car2 = new Carro( car1 );  // clona o carro car1
        
        System.out.println( car1.mostraCarro() );
        System.out.println( car2.mostraCarro() );
        
        System.out.println(car1.iguais(car2));
    }
}
