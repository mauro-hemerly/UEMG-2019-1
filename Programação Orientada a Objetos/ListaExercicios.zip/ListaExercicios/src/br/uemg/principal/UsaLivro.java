 
package br.uemg.principal;

import br.uemg.classes.Livro;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class UsaLivro {
    public static void main(String[] args) {
        Livro l1 = Livro.criaLivro( "John Grishan","Nova","Dossiê Pelicano",200);
        Livro l2 = new Livro( l1 );  // clonou l1
        Livro l3 = l1;
        Livro l4 = new Livro ( "John Grishan","Nova","Dossiê Pelicano",200);
        
        l1.setTitulo( "O Culpado");
        
        System.out.println("Autor (l1): " + l1.getTitulo()  );
             
        System.out.println("Autor (l3): " + l3.getTitulo() );
        
        System.out.println("Autor (l2): " + l2.getTitulo() );
        
        System.out.println(l1);
    }
}
