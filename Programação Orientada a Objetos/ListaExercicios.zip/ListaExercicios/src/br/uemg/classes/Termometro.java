
package br.uemg.classes;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Termometro {
    private int temperatura;   // em Celsius:  varia de 10 a 150 
    private final int ESCALA_MAX = 150;
    private final int ESCALA_MIN = 10;
    private final int VARIACAO = 5; // variação de 5 graus celsius
    
    // Construtor de cópia
    public Termometro( Termometro term ) {
        this.temperatura = term.temperatura;
        
    }
    
    // Construtor default
    public Termometro() {
        temperatura = 15;   // temperatura inicial
    }
    
    public boolean aquecer() {
        if ( temperatura < ESCALA_MAX ) {
            temperatura += VARIACAO;   // temperatura = temperatura + 5
            return true;
        }
        return false;  // não foi possível aquecer. Atingiu a escala máxima
    }
    
   
    
    public boolean esfriar() {
        if ( temperatura > ESCALA_MIN ) {
            temperatura -= VARIACAO;   // temperatura = temperatura + 5
            return true;
        }
        return false;  // não foi possível esfriar. Atingiu a escala mínima
    }
    
    // Convenção 'JavaBeans: usar prefixo get
    public int getTemperatura() {
        return temperatura;
    }
    
    public boolean iguais( Termometro term ) {
        if ( this == term ) {
            return true;
        }
        return this.temperatura == term.temperatura;
    }
    
    
}
