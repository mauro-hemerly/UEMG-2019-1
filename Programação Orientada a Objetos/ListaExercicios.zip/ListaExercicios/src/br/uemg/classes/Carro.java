 
package br.uemg.classes;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Carro {
    private String cor;
    private String marca;
    private String modelo;
    private String combustivel;
    

    private Carro(String cor, String marca, String modelo, String combustivel) {
        this.cor = cor;
        this.marca = marca;
        this.modelo = modelo;
        this.combustivel = combustivel;
    }
    
    // Construtor de cópia
    public Carro( Carro car ) {
        this.cor = car.cor;
        this.marca = car.marca;
        this.modelo = car.modelo;
        this.combustivel = car.combustivel;
    }
    
    
    // Método fábrica
    public static Carro criaCarro( String cor, String marca, String modelo, String combustivel ) {
        return new Carro( cor,  marca,   modelo,   combustivel);
    }
    
    public String mostraCarro() {
        return "Marca: " + marca + "\nModelo: "+ modelo + 
                "\nCombustivel: " + combustivel + "\nCor: " + cor;
    }
    
    
    public boolean iguais( Carro car ) {
        if (this == car ) {
            return true;
        }
        return  this.combustivel.equals(car.combustivel) &&
                this.cor.equals(car.cor) && 
                this.marca.equals(car.marca) &&
                this.modelo.equals(car.modelo);
    }

}
