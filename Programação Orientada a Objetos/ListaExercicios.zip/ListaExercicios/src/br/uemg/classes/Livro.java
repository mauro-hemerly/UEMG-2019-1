
package br.uemg.classes;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Livro {
    private String autor;
    private String editora;
    private String titulo;
    private int qtde;
    
    
    // Método fábrica
    
    public static Livro criaLivro( String autor, String edit, String tit, int qtde ) {
        return new Livro( autor, edit, tit, qtde );
    }
    
    public Livro  ( String autor, String edit, String tit, int qtde ) {
         this.autor = autor;
         editora = edit;
         titulo = tit;
         this.qtde = qtde;
    }
    
    // Construtor de cópia
    public Livro( Livro livro ) {
         autor = livro.autor;
        editora = livro.editora;
         titulo = livro.titulo;
         //qtde = livro.qtde;
         
         //this(livro.autor, livro.editora, livro.titulo, livro.qtde);
         
    }
    
    

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getQtde() {
        return qtde;
    }

    public void setQtde(int qtde) {
        this.qtde = qtde;
    }

    
    public boolean iguais( Livro l ) {
        if ( this == l ) {
            return true;
        }
        
        return this.autor.equals(l.autor) && 
               this.titulo.equals(l.titulo) &&
               this.editora.equals(l.editora) &&
               this.qtde == l.qtde;
       
    }

    @Override
    public String toString() {
        return "Livro{" + "autor=" + autor + ", editora=" + editora + ", titulo=" + titulo + ", qtde=" + qtde + '}';
    }
    
    
    
    
}
