/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.uemg.classes;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Televisao {
    private boolean status; // on = true     off = false
    private int canal;  // cana maximo = 15
    private final int CANAL_MAX = 15;   // maior numero de canal
    private final int CANAL_MIN = 1;   // menor numero de canal
    
    public Televisao()  {
        status = false;
        canal = 11;
    }
    
    // Se esJver ligado ele desliga e se esJver desligado ele liga.
    public void ligaDesliga( ) {
        status = !status;
    }
    
    public boolean trocaCanal( int novoCanal ) {
        if ( ( novoCanal >= CANAL_MIN ) && ( novoCanal <= CANAL_MAX ) ) {
            canal = novoCanal;
            return true;
        }
        return false;
    }
    
    
    public boolean iguais( Televisao tv ) {
        if ( this == tv ) {
            return true;
        }
        
//        if ( ( this.status ==  tv.status ) && ( this.canal ==  tv.canal ) ) {
//            return true;
//        }
        
        return ( ( this.status ==  tv.status ) && ( this.canal ==  tv.canal ) );
    }
    
    
    @Override
    public String toString() {
        return "Status: " + (status ? "On" : "Off") + "  Canal: " + canal;
                                           
    }
    
    public void avancaCanal() {
//        if ( canal < CANAL_MAX ) {
//            canal++;
//        }
//        else {
//            canal = CANAL_MIN;
//        }
        
        canal = (canal % CANAL_MAX) + 1;
            
    }
    
    public String verStatus() {
        return toString();
    }
    
}












