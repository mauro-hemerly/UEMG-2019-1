
package br.uemg.principal;

//import br.uemg.classes.*;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class UsaContaCorrente {
    public static void main(String[] args) {
        int i = 99;
     
        
        // Usa construtor com parâmetros
        br.uemg.classes.ContaCorrente cc3 = new br.uemg.classes.ContaCorrente("5678", 999.99);
        br.uemg.classes.ContaCorrente cc4 = new br.uemg.classes.ContaCorrente("7890", 888.88);
        
        System.out.println("Conta: " + cc3.obterNumero() + "   Saldo: "+ cc3.obterSaldo());
        System.out.println("Conta: " + cc4.obterNumero() + "   Saldo: "+ cc4.obterSaldo());
        
        
        cc3.depositar(1000.00);
        cc4.sacar(500.00);
        
         System.out.println("\n\n\n");
        
        System.out.println("Conta: " + cc3.obterNumero() + "   Saldo: "+ cc3.obterSaldo());
        System.out.println("Conta: " + cc4.obterNumero() + "   Saldo: "+ cc4.obterSaldo());
        
    
    }
            
            
            
}
