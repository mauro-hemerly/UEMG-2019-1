
package br.uemg.classes;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class ContaCorrente {
   private String numero;
   private double saldo;
    
    
//    // Construtor default
//    public ContaCorrente() {
//        numero = "123456-9";
//        saldo = 100.00;
//    }
//    
//    
//    // Construtor com Parâmetros
    public ContaCorrente( String num, double saldoInicial ) {
        numero = num;
        saldo = saldoInicial;
    }
    
    
    public void depositar( double valor ) {
        saldo = saldo + valor;     // saldo += valor;
    }
    
    
    public boolean sacar( double valor ) {
        if ( valor < saldo ) {
            saldo = saldo - valor;    // saldo -= valor;
            return true;
        }
        
        return false;  // saque não foi autorizado
    }
    
    
    public String obterNumero() {
        return numero;
    }
    
    
    public double obterSaldo() {
        return saldo;
    }
    
}
