
package matematicadiscreta;

import java.util.*;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class OperacoesConjuntos {

    public static void main(String[] args) {

        // Conjunto A
        Set<Integer> conjuntoA = new HashSet<Integer>();

        Integer[] arrayA = {1, 3, 2, 4, 4, 8, 9, 0};

        conjuntoA.addAll(Arrays.asList(arrayA));  // Popula o conjunto A
        System.out.print("Conjunto A: "); 
        System.out.println(conjuntoA); 
        

        // Conjunto B
        Set<Integer> conjuntoB = new HashSet<Integer>();

        Integer[] arrayB = {1, 3, 7, 5, 4, 0, 7, 5};

        conjuntoB.addAll(Arrays.asList(arrayB));  // Popula o conjunto B
        System.out.print("Conjunto B: "); 
        System.out.println(conjuntoB); 
        
        //Operação de União
        Set<Integer> uniao = new HashSet<Integer>(conjuntoA); 
        uniao.addAll(conjuntoB); 
        System.out.print("União dos Conjuntos A e B:"); 
        System.out.println(uniao); 
        
        
        //Operação de Interseção 
        Set<Integer> intersecao = new HashSet<Integer>(conjuntoA); 
        intersecao.retainAll(conjuntoB); 
        System.out.print("Interseção dos Conjuntos A e B: "); 
        System.out.println(intersecao); 
        
        //Operação de Diferença 
        Set<Integer> diferenca = new HashSet<Integer>(conjuntoA); 
        diferenca.removeAll(conjuntoB); 
        System.out.print("Conjunto Diferença de A e B: "); 
        System.out.println(diferenca);               
        
    }
}
