
package matematicadiscreta;

import java.util.*;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Conjuntos {

    public static void main(String[] args) {
       
        // Definição e criação de conjuntos por meio de array
        
        // Conjunto A
        Set<Integer> conjuntoA = new HashSet<Integer>(); 
        
        Integer[] arrayA = {1, 3, 2, 4, 8, 9, 0};
        conjuntoA.addAll(Arrays.asList(arrayA));  // Popula conjunto A
        
        // Conjunto AA
        Set<Integer> conjuntoAA = new HashSet<Integer>(); 
        
        Integer[] arrayAA = {1, 3, 2, 4, 4, 8, 9, 0};
        conjuntoAA.addAll(Arrays.asList(arrayAA));    // Popula conjunto AA
        
        // Conjunto B
        Set<Integer> conjuntoB = new HashSet<Integer>(); 
        
        Integer[] arrayB = {1, 3, 7, 5, 4, 0, 7, 5};
        conjuntoB.addAll(Arrays.asList(arrayB));     // Popula conjunto B
        
        System.out.print("Conjunto Numérico A:"); 
        System.out.println(conjuntoA); 
        
        System.out.print("Conjunto Numérico AA:"); 
        System.out.println(conjuntoAA); 
        
        System.out.print("Conjunto Numérico B:"); 
        System.out.println(conjuntoB); 
        
        System.out.print("Conjuntos A e AA são iguais? ");
        System.out.println(conjuntoA.equals(conjuntoAA)); 
        
        System.out.print("Conjuntos A e B são iguais? ");
        System.out.println(conjuntoA.equals(conjuntoB)); 
        
        System.out.print("Cardinalidade do Conjunto A:"); 
        System.out.println(conjuntoA.size()); 
        
        System.out.print("Cardinalidade do Conjunto AA:"); 
        System.out.println(conjuntoAA.size()); 
        
        System.out.print("Cardinalidade do Conjunto B:"); 
        System.out.println(conjuntoB.size()); 
                
    }
    
}
