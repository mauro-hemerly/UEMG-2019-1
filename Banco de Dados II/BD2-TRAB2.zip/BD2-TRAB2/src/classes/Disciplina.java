 
package classes;

import java.util.ArrayList;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Disciplina {
    private String codigo;
    private String nome;
    private String professor;
    private ArrayList<Matricula> alunos;

    public Disciplina(String codigo, String nome, String professor) {
        this.codigo = codigo;
        this.nome = nome;
        this.professor = professor;
        this.alunos = alunos;
        alunos = new ArrayList<>();
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProfessor() {
        return professor;
    }

    public void setProfessor(String professor) {
        this.professor = professor;
    }

    public ArrayList<Aluno> getAlunosDaDisciplina() {
        ArrayList<Aluno> resultado = new ArrayList<>();
        for(Matricula m : alunos) {
            resultado.add(m.getAluno());
        }
        return resultado;
    }
    
    
    public void setMatricula(Matricula m) {
        alunos.add(m);
    }
    
    @Override
    public String toString() {
        return "Disciplina{" + "codigo=" + codigo + ", nome=" + nome + ", professor=" + professor  + '}';
    }    
}
