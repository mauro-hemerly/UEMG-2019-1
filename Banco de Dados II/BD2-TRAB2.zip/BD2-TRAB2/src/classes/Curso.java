 
package classes;

import java.util.ArrayList;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Curso {
    private String nomeCurso;
    private String codigo;
    private String coordenador;
    private ArrayList<Turma> turmas;

    public Curso(String nomeCurso, String codigo, String coordenador) {
        this.nomeCurso = nomeCurso;
        this.codigo = codigo;
        this.coordenador = coordenador;
        turmas = new ArrayList<>();
    }

     
    public void cadastraTurmaNoCurso(Turma turma) {
        turmas.add(turma);
    }
    
    public boolean cadastraDisciplina(Disciplina disciplina, Turma turma) {
        if (!turmas.contains(turma) && !turma.getDisciplinas().contains(disciplina)) {    
            for(Turma t : turmas) {
                if (t.getCodigo().equals(turma.getCodigo())) {
                    t.cadastraDisciplinaNaTurma(disciplina);
                }  
            }
            return true;
            
        }
        return false;
    }

    public String getNomeCurso() {
        return nomeCurso;
    }

    public void setNomeCurso(String nomeCurso) {
        this.nomeCurso = nomeCurso;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getCoordenador() {
        return coordenador;
    }

    public void setCoordenador(String coordenador) {
        this.coordenador = coordenador;
    }

    public ArrayList<Turma> getTurmas() {
        return turmas;
    }

    @Override
    public String toString() {
        return "Curso{" + "nomeCurso=" + nomeCurso + ", codigo=" + codigo + ", coordenador=" + coordenador + ", turmas=" + turmas + '}';
    }
}
