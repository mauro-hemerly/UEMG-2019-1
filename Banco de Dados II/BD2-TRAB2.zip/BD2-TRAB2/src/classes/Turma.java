 
package classes;

import java.util.ArrayList;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Turma {
    private String periodo;
    private String codigo;
    private ArrayList<Disciplina> disciplinas;

    public Turma(String periodo, String codigo) {
        this.periodo = periodo;
        this.codigo = codigo;
        disciplinas = new ArrayList<>();
    }
    
    public void cadastraDisciplinaNaTurma(Disciplina d) {
        disciplinas.add(d);
    }   

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public ArrayList<Disciplina> getDisciplinas() {
        return disciplinas;
    }

    @Override
    public String toString() {
        return "Turma{" + "periodo=" + periodo + ", codigo=" + codigo + ", disciplinas=" + disciplinas + '}';
    }

   
    
    
    
    
    
}
