 
package classes;

import java.util.ArrayList;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Aluno {
    private String codigo;
    private String nome;
    private String cpf;
    private ArrayList<Matricula> disciplinas;

    public Aluno(String codigo, String nome, String cpf) {
        this.codigo = codigo;
        this.nome = nome;
        this.cpf = cpf;
        disciplinas = new ArrayList<>();
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public ArrayList<Disciplina> getDisciplinasDoAluno() {
        ArrayList<Disciplina> resultado = new ArrayList<>();
        for(Matricula m : disciplinas) {
            resultado.add(m.getDisciplina());
        }
        return resultado;
    }

  
    public void matriculaAlunoDisciplina(Disciplina disc, String semestre, String turno) {
        disciplinas.add(new Matricula(this,disc,semestre,turno));
    }

    @Override
    public String toString() {
        return "Aluno{" + "codigo=" + codigo + ", nome=" + nome + ", cpf=" + cpf + '}';
    }
}
