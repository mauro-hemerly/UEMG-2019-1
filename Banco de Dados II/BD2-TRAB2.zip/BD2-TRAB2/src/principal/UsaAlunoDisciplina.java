package principal;

import classes.Aluno;
import classes.Disciplina;
import java.util.ArrayList;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class UsaAlunoDisciplina {

    public static void main(String[] args) {
        Disciplina disc1 = new Disciplina("EC-111", "Introdução à Programação", "Olavo Setubal");
        Disciplina disc2 = new Disciplina("EC-222", "Linguagens de Programação", "Renato Pereira");
        Disciplina disc3 = new Disciplina("EC-333", "Programação Funcional", "Carlos Roberto");

        Aluno al1 = new Aluno("123", "Jose Carlos da Silva", "123.456.789-00");
        al1.matriculaAlunoDisciplina(disc1,"2019/1","integral");
        al1.matriculaAlunoDisciplina(disc2,"2019/1","integral");
        al1.matriculaAlunoDisciplina(disc3,"2019/1","integral");
       

        Aluno al2 = new Aluno("753", "Marcio da Nobrega", "111.222.333-99");
        al2.matriculaAlunoDisciplina(disc1,"2019/1","integral");
        al2.matriculaAlunoDisciplina(disc2,"2019/1","integral");
        
        Aluno al3 = new Aluno("888", "Marcelo Silva", "345.789.456-33");
        al3.matriculaAlunoDisciplina(disc1,"2019/1","integral");
        al3.matriculaAlunoDisciplina(disc3,"2019/1","integral");
       
        Aluno al4 = new Aluno("888", "Ary Fontoura", "125.645.342-88");
        al4.matriculaAlunoDisciplina(disc2,"2019/1","integral");
        al4.matriculaAlunoDisciplina(disc3,"2019/1","integral");   
        
        
        
        //******** RELATÓRIOS ***************
        
        System.out.println("Relatório de disciplinas de determinado aluno...");
        ArrayList<Disciplina> disciplinas = al1.getDisciplinasDoAluno();     
        System.out.println("\nDisciplinas do aluno al1");
        for (Disciplina d : disciplinas) {
            System.out.println(d);
        }
        
        disciplinas = al2.getDisciplinasDoAluno();     
        System.out.println("\nDisciplinas do aluno al2");
        for (Disciplina d : disciplinas) {
            System.out.println(d);
        }
        
        disciplinas = al3.getDisciplinasDoAluno();     
        System.out.println("\nDisciplinas do aluno al3");
        for (Disciplina d : disciplinas) {
            System.out.println(d);
        }
        
        disciplinas = al4.getDisciplinasDoAluno();     
        System.out.println("\nDisciplinas do aluno al4");
        for (Disciplina d : disciplinas) {
            System.out.println(d);
        }

 
        
        System.out.println("\n\nRelatório de alunos de determinada disciplina...");
         ArrayList<Aluno> alunos = disc1.getAlunosDaDisciplina(); 
         System.out.println("\nAlunos da disciplina disc1");
         for (Aluno a : alunos) {
            System.out.println(a);
        }
         
        alunos = disc2.getAlunosDaDisciplina(); 
        System.out.println("\nAlunos da disciplina disc2");
        for (Aluno a : alunos) {
            System.out.println(a);
        }
         
        alunos = disc3.getAlunosDaDisciplina(); 
        System.out.println("\nAlunos da disciplina disc3");
        for (Aluno a : alunos) {
            System.out.println(a);
        }
        
        

    }
}
