
package Principal;

import Classes.DAO;
import Classes.DAOPessoa;
import Classes.Pessoa;
import java.util.ArrayList;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Usadb4o {
    public static void main(String[] args) {
         DAO<Pessoa> dao = new DAO<>("db4o.yap"); // cria objeto de acesso a dados
        
        Pessoa pes1; 
        pes1 = new Pessoa("Ricardo",35);
        //inserePessoa(pes1,dao);
           
        // Pesquisa pessoa por idade
        pes1 = new Pessoa();
        pes1.setIdade(25);
        listaPessoas(pes1, dao);
              
        //listaTodasPessoas(dao);
        
        
    }
    
    private static void inserePessoa(Pessoa pes, DAOPessoa dao) {
         dao.insert(pes);
    }
    
    // Usando polimorfismo paramétrico
    private static void inserePessoa(Pessoa pes, DAO<Pessoa> dao) {
         dao.insert(pes);
    }
    
     
    
    // Usando polimorfismo paramétrico
    private static void listaPessoas(Pessoa pes, DAO<Pessoa> dao) {
        ArrayList<Pessoa> listaPessoas = dao.select(pes);
        for(Pessoa p : listaPessoas) {
            System.out.println(p);
        }
    }
    
    
    
    private static void listaTodasPessoas(DAOPessoa dao) {
        ArrayList<Pessoa> listaPessoas = dao.selectAll();
        for(Pessoa p : listaPessoas) {
            System.out.println(p);
        }
    }
     
     // Usando polimorfismo paramétrico
    private static void listaTodasPessoas(DAO<Pessoa> dao) {
        ArrayList<Pessoa> listaPessoas = dao.selectAll();
        for(Pessoa p : listaPessoas) {
            System.out.println(p);
        }
    }
    
} // fim da classe
