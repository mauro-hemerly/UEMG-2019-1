
package Principal;

import Classes.DAO;
import Classes.DAOPessoa;
import Classes.Pessoa;
import java.util.ArrayList;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Usadb4o {
    public static void main( String[] args ) throws Exception {
        DAO<Pessoa> dao = new DAO<>( "db4o.yap" ); // cria objeto de acesso a dados
        
        Pessoa pes1; 
        pes1 = new Pessoa( "Antonio Carlos",25 );
        //inserePessoa(pes1,dao); 
           
        // Pesquisa pessoa por idade (usando construtor default)
        //pes1 = new Pessoa();
        //pes1.setIdade(25);
        
        // Pesquisa pessoa por idade (usando construtor com parâmetros)
        pes1 = new Pessoa( null,13 );
        //listaPessoa(pes1, dao);
              
        //pes1 = new Pessoa( "Antonio Carlos",0 );
        //excluiPessoa( pes1,dao );
        
     
        Pessoa novaPessoa = new Pessoa("Veronica", 19);
        //atualizaPessoa( pes1,novaPessoa,dao );
        listaTodasPessoas( dao );  
      
    }
    
 
    
    // Usando polimorfismo paramétrico
    private static void inserePessoa( Pessoa pes, DAO<Pessoa> dao ) {
         dao.insert( pes );
    }
         
    
    // Usando polimorfismo paramétrico
    private static void listaPessoa( Pessoa pes, DAO<Pessoa> dao ) {
        Pessoa p  = dao.select( pes );
        System.out.println( p );
    }
    
     
    // Usando polimorfismo paramétrico
    private static void listaTodasPessoas( DAO<Pessoa> dao ) {
        ArrayList<Pessoa> listaPessoas = dao.selectAll();
        for( Pessoa p : listaPessoas ) {
            System.out.println( p );
        }
    }
    
    // Usando polimorfismo paramétrico
    private static void atualizaPessoa( Pessoa query, Pessoa novaPessoa, DAO<Pessoa> dao ) throws Exception {
        dao.update( query,novaPessoa );
    }
    
    
    // Usando polimorfismo paramétrico
    private static void excluiPessoa( Pessoa pes, DAOPessoa dao ) {
        dao.delete(pes);
    }
    
} // fim da classe
