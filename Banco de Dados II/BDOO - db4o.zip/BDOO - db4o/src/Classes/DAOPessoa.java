 
package Classes;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import java.util.ArrayList;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class DAOPessoa {
    private ObjectContainer bd = null;
    private final String banco;
    
    public DAOPessoa(String banco) {
        this.banco = banco;
    }
    
    private void openBD() {
        bd = Db4oEmbedded.openFile( banco );
        
    }
    
    private void closeBD() {
         bd.close();
        
    }
    
    //CREATE
    public void insert( Pessoa ob ) {
        openBD();
        bd.store( ob );  // persiste no bd
        closeBD();
    }
    
    //READ
    public Pessoa select( Pessoa ob ) {
        Pessoa objeto = null;
        
        openBD();
        ObjectSet<Pessoa> objetos = bd.queryByExample( ob );
       
        if ( objetos.hasNext() ) {    // verifica se foi encontrado algum objeto
            objeto = objetos.next();  // pega primeiro
        }
        
        closeBD();
        
        return objeto;
    }
    
    
    
    public ArrayList<Pessoa> selectAll() {
        openBD();
        ObjectSet<Pessoa> objetos = bd.queryByExample( Object.class );
        ArrayList<Pessoa> listaObjetos = new ArrayList<>();
        
        for(Pessoa obj : objetos) {
            listaObjetos.add( obj );
        }
        
        closeBD();
        return listaObjetos;
    }
    
    //UPDATE
    public void update( Pessoa ob, Pessoa novoObjeto ) {
        openBD();
        ObjectSet<Pessoa> objetos = bd.queryByExample( ob );
        if ( objetos.hasNext() ) {
            Pessoa found = (Pessoa)objetos.next();
            Pessoa.clona( novoObjeto,found );
            bd.store( found );
        }
        closeBD();
    }
    
    
    
    
    //DELETE
    public void delete( Pessoa ob ) {
        openBD();
        ObjectSet<Pessoa> objetos = bd.queryByExample( ob );
        Pessoa objeto;
        if ( objetos.hasNext() ) {  // verifica se foi encontrado algum objeto
            objeto = (Pessoa)objetos.next();  // pega o primeiro
            bd.delete( objeto );  // remove a primeira ocorrência do bd
        }
        closeBD();
    }
}
