 
package Classes;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.ext.ExtObjectContainer;
import com.db4o.reflect.jdk.JdkReflector;
import java.util.ArrayList;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class DAO<T> {
    private ObjectContainer bd = null;
    private final String banco;
    
    public DAO(String banco) {
        this.banco = banco;
    }
    
    private void openBD() {
        bd = Db4oEmbedded.openFile( banco );
        
    }
    
    private void closeBD() {
         bd.close();
        
    }
    
    //CREATE
    public void insert( T ob ) {
        openBD();
        bd.store( ob );  // persiste no bd
        closeBD();
    }
    
    //READ
    public T select( T ob ) {
        T objeto = null;
        
        openBD();
        ObjectSet<T> objetos = bd.queryByExample( ob );
       
        if ( objetos.hasNext() ) {    // verifica se foi encontrado algum objeto
            objeto = objetos.next();  // pega primeiro
        }
        
        closeBD();
        
        return objeto;
    }
    
    
    
    public ArrayList<T> selectAll() {
        openBD();
        ObjectSet<T> objetos = bd.queryByExample( Object.class );
        ArrayList<T> listaObjetos = new ArrayList<>();
        
        for(T obj : objetos) {  // percorre  lista de objetos de ObjectSet e adiciona ao ArrayList
            listaObjetos.add( obj );
        }
        
        closeBD();
        return listaObjetos;
    }
    
    //UPDATE
    public void update( T ob, T novoObjeto ) throws Exception {
        openBD();
        ObjectSet<T> objetos = bd.queryByExample( ob );
        if ( objetos.hasNext() ) {
            T found = objetos.next();
            Class c = found.getClass();
            c.getDeclaredMethod( "clona",c,c ).invoke( c,novoObjeto, ob );
            bd.store(found);
        }
        closeBD();
    }
    
    
    
    
    //DELETE
    public void delete( T ob ) {
        openBD();
        ObjectSet<T> objetos = bd.queryByExample( ob );
        T objeto;
        if ( objetos.hasNext() ) {  // verifica se foi encontrado algum objeto
            objeto = (T)objetos.next();  // pega o primeiro
            bd.delete( objeto );  // remove a primeira ocorrência do bd
        }
        closeBD();
    }
}
