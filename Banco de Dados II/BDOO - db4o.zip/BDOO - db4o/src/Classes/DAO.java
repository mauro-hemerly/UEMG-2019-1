 
package Classes;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.ext.DatabaseClosedException;
import com.db4o.ext.Db4oIOException;
import java.util.ArrayList;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class DAO<T> {
    private ObjectContainer bd = null;
    private final String banco;
    
    public DAO(String banco) {
        this.banco = banco;
    }
    
    private void openBD() {
        try {
            bd = Db4oEmbedded.openFile(banco);
        }catch(Db4oIOException  e) {
            System.out.println("Erro: falhou acesso ao banco de dados...");
        }
    }
    
    private void closeBD() {
        if (bd != null) {
                try {
                    bd.close();
                }
                catch(DatabaseClosedException e) {
                    System.out.println("Erro: nao foi possível fechar banco de dados...");        
                }
            }
    }
    
    //CREATE
    public void insert(T p) {
        openBD();
        bd.store(p);
        closeBD();
    }
    
    //READ
    public ArrayList<T> select(T p) {
        openBD();
        ObjectSet<T> result = bd.queryByExample(p);
        ArrayList<T> listaObjetos = new ArrayList<>();
        for(T pes : result) {
            listaObjetos.add(pes);
        }
        closeBD();
        
        return listaObjetos;
    }
    
    public ArrayList<T> selectAll() {
        openBD();
        ObjectSet<T> objetos = bd.queryByExample(Object.class);
        ArrayList<T> listaObjetos = new ArrayList<>();
        
        for(T obj : objetos) {
            listaObjetos.add(obj);
        }
        
        closeBD();
        return listaObjetos;
    }
    
    //UPDATE
    public void update() {
        
    }
    
    //DELETE
    public void delete() {
        
    }
}
